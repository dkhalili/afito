import React, { Component } from "react";

export default class Contact extends Component {
  render() {
    return (
      <div id="contact">
        This is the contact me page.
      </div>
    );
  }
}