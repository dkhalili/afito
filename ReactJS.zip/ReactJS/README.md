# react-about-me
author: [krithix](https://twitter.com/krithix)

A simple multi-page webapp using React, react-router, Webpack, and Express (with support for babel and SASS).

A full write up and guide is available on [this Medium post](https://medium.com/@krithix/multi-page-website-with-react-in-2017-f6f2af326526).
